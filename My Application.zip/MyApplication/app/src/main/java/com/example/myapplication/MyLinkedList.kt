package com.example.myapplication

class MyLinkedList {
}