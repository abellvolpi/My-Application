package com.example.myapplication

class MyArrayList<T : Any> : PSList<T> {

    private var dataArray: Array<Any?> = Array(DEFAULT_LIST_INIT_SIZE) {
        Any()
    }
    private var count = 0

    override fun contains(item: T): Boolean {
        dataArray.forEach {
            if (it == item) {
                return true
            }
        }

        return false
    }

    (...)